import React from 'react';
import { Calendar, GraduationCap } from 'lucide-react';
import { motion } from 'framer-motion';

const education = [
  {
    school: 'Siddharth Institute of Engineering And Technology',
    location: 'Puttur, Andhra Pradesh',
    degree: 'Bachelor of Technology',
    field: 'Computer Science And Information Technology',
    period: '2021 - 2025',
    grade: 'SGPA: 7.5',
  },
  {
    school: 'Sri Siddartha Junior College',
    location: 'Madanapalle, Andhra Pradesh',
    degree: 'Intermediate',
    field: 'Primary Education',
    period: '2019 - 2021',
    grade: 'SGPA: 4.9',
  },
  {
    school: 'Vijaya Bharathi School',
    location: 'Madanapalle',
    degree: 'Secondary School of Education',
    field: '',
    period: '2018 - 2019',
    grade: 'SGPA: 9.5',
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.3
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5
    }
  }
};

function Education() {
  return (
    <motion.div 
      className="relative"
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
    >
      {/* Timeline line */}
      <div className="absolute left-4 md:left-1/2 transform md:-translate-x-1/2 h-full w-0.5 bg-gray-200"></div>
      
      {/* Timeline items */}
      <div className="space-y-12">
        {education.map((edu, index) => (
          <motion.div 
            key={index} 
            className={`relative flex items-start ${
              index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
            }`}
            variants={itemVariants}
          >
            {/* Timeline dot */}
            <motion.div 
              className="absolute left-4 md:left-1/2 transform -translate-x-1/2 w-4 h-4 bg-indigo-600 rounded-full border-4 border-white"
              initial={{ scale: 0 }}
              whileInView={{ scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            ></motion.div>
            
            {/* Content */}
            <div className={`ml-12 md:ml-0 md:w-1/2 ${
              index % 2 === 0 ? 'md:pr-12' : 'md:pl-12'
            }`}>
              <div className="bg-white p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <div className="flex items-center gap-2 mb-2">
                  <GraduationCap className="w-5 h-5 text-indigo-600" />
                  <h3 className="text-xl font-semibold text-gray-900">{edu.school}</h3>
                </div>
                <p className="text-lg text-indigo-600 font-medium">{edu.degree}</p>
                {edu.field && (
                  <p className="text-gray-600 mt-1">{edu.field}</p>
                )}
                <div className="flex items-center gap-4 mt-3 text-gray-600">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    <span className="text-sm">{edu.period}</span>
                  </div>
                  <span className="font-medium text-sm text-indigo-600">{edu.grade}</span>
                </div>
                <p className="text-sm text-gray-500 mt-2">{edu.location}</p>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

export default Education;