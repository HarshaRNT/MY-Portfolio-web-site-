import React from 'react';
import { motion } from 'framer-motion';

const skillCategories = [
  {
    title: 'Programming Languages',
    skills: [
      { name: 'Python' },
      { name: 'Java' },
      { name: 'HTML' },
      { name: 'CSS' },
      { name: 'JavaScript' },
    ],
  },
  {
    title: 'Frameworks & Libraries',
    skills: [
      { name: 'Flask' },
      { name: 'Bootstrap' },
      { name: 'Scikit-learn' },
      { name: 'Pandas' },
      { name: 'Matplotlib' },
    ],
  },
  {
    title: 'Tools & Technologies',
    skills: [
      { name: 'Git' },
      { name: 'VS Code' },
      { name: 'MySQL' },
      { name: 'RESTful APIs' },
    ],
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.2
    }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5
    }
  }
};

function Skills() {
  return (
    <motion.div 
      className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
    >
      {skillCategories.map((category, index) => (
        <motion.div 
          key={index} 
          className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow"
          variants={itemVariants}
        >
          <h3 className="text-xl font-semibold text-gray-900 mb-6">{category.title}</h3>
          <div className="flex flex-wrap gap-3">
            {category.skills.map((skill, skillIndex) => (
              <motion.span
                key={skillIndex}
                className="px-4 py-2 bg-gray-50 text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
                whileHover={{ scale: 1.05 }}
                transition={{ type: "spring", stiffness: 400, damping: 10 }}
              >
                {skill.name}
              </motion.span>
            ))}
          </div>
        </motion.div>
      ))}
    </motion.div>
  );
}

export default Skills;